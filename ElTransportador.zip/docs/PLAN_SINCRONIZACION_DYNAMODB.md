# Plan Arquitectónico de Sincronización Híbrida Local-First y Base de Datos Remota Compartida con Amazon DynamoDB — ElTransportador v1.0.0

- **Aplicación:** ElTransportador (`com.eltransportador.desktop`)
- **Versión base:** `v1.0.0`
- **Motor local actual:** Archivos `.etp.json` + SQLite (`WAL`) + Bóveda local `AES-256-GCM` / Keyring del SO
- **Motor remoto proyectado:** **Amazon DynamoDB** (Diseño Single-Table + Sincronización Selectiva Push/Pull)

## 1. Objetivo Arquitectónico

ElTransportador mantiene su principio fundamental **Local-First** (funcionamiento 100% autónomo sin cuentas obligatorias ni bloqueo por falta de internet), incorporando una capa opcional de **Almacenamiento Remoto Compartido en Amazon DynamoDB** para equipos de ingeniería que necesitan compartir colecciones, solicitudes y flujos de validación.

El diseño garantiza tres capacidades esenciales:
1. **Control selectivo por entidad (`policy`):** El usuario decide explícitamente qué colecciones, solicitudes o flujos se quedan **exclusivamente en local (`local_only`)** y cuáles se envían a la base remota compartida (**`remote_shared`**).
2. **Etiquetas visuales de identificación de sincronización (`status`):** Cada colección, solicitud y flujo muestra en todo momento una etiqueta clara en la interfaz:
   - `🔒 Solo Local` (`local_only`): Nunca se transmite fuera del equipo.
   - `⏳ Pendiente Sync` (`pending_push`): Tiene cambios locales aún no enviados a DynamoDB.
   - `☁ Sincronizado` (`synced`): Su versión y huella criptográfica (`SHA-256`) coinciden exactamente con el registro en DynamoDB.
   - `⚠ Conflicto` (`conflict`): Existe una versión más reciente en DynamoDB modificada por otro integrante del equipo.
3. **Protección estricta de secretos (Zero-Plaintext Cloud):** La bóveda `SecretVault` jamás envía secretos en texto plano a DynamoDB; las solicitudes sincronizadas conservan únicamente referencias simbólicas `${secret:nombre_clave}`.

## 2. Diseño de Tabla en Amazon DynamoDB (Single-Table Design)

Se utiliza una única tabla en Amazon DynamoDB llamada por defecto `ElTransportador_SharedWorkspace` en modo **On-Demand (`PAY_PER_REQUEST`)**, optimizada para consultas por espacio de trabajo y sincronización incremental (Delta Sync).

### 2.1 Esquema de Claves Primarias e Índices

| Atributo | Tipo | Función en DynamoDB | Formato / Ejemplo |
| :--- | :--- | :--- | :--- |
| **`PK`** | `String` (Partition Key) | Identifica el espacio de trabajo compartido (`Workspace`) | `WS#ws_team_toluca_01` |
| **`SK`** | `String` (Sort Key) | Identifica jerárquicamente la entidad (`Collection`, `Folder`, `Request`, `Flow`, `Environment`) | `COL#col_01`, `COL#col_01#REQ#req_09`, `FLW#flw_03` |
| **`GSI1PK`** | `String` (GSI Partition Key) | Agrupa entidades por tipo o estado dentro del espacio de trabajo | `WS#ws_team_toluca_01#TYPE#REQUEST` |
| **`GSI1SK`** | `String` (GSI Sort Key) | Permite consultar cambios incrementales (`Delta Pull`) por fecha de actualización | `UPDATED#2026-10-14T20:00:00.000Z#REQ#req_09` |
| **`entityType`** | `String` | Tipo de documento | `COLLECTION` \| `FOLDER` \| `REQUEST` \| `FLOW` \| `ENVIRONMENT` |
| **`version`** | `Number` | Contador monotónico para bloqueo optimista (`Optimistic Locking`) | `1`, `2`, `3`... |
| **`contentHash`** | `String` | Huella `SHA-256` del payload canónico JSON | `sha256:9f86d081884c...` |
| **`updatedAt`** | `String` (ISO-8601) | Marca de tiempo de la última modificación | `2026-10-14T20:05:12Z` |
| **`updatedBy`** | `String` | Identificador del autor o nodo cliente | `dev_sergio@equipo` |
| **`payload`** | `Map` | Contenido completo de la colección, solicitud o flujo (con secretos redactados) | `{ "method": "POST", "url": "${base_url}/orders", ... }` |

### 2.2 Definición de Infraestructura (AWS CLI / CloudFormation / Terraform)

```bash
aws dynamodb create-table \
  --table-name ElTransportador_SharedWorkspace \
  --attribute-definitions \
      AttributeName=PK,AttributeType=S \
      AttributeName=SK,AttributeType=S \
      AttributeName=GSI1PK,AttributeType=S \
      AttributeName=GSI1SK,AttributeType=S \
  --key-schema \
      AttributeName=PK,KeyType=HASH \
      AttributeName=SK,KeyType=RANGE \
  --global-secondary-indexes '[
    {
      "IndexName": "GSI1_DeltaSync",
      "KeySchema": [
        {"AttributeName": "GSI1PK", "KeyType": "HASH"},
        {"AttributeName": "GSI1SK", "KeyType": "RANGE"}
      ],
      "Projection": {"ProjectionType": "ALL"}
    }
  ]' \
  --billing-mode PAY_PER_REQUEST
```

## 3. Metadatos de Sincronización en cada Entidad (`syncMeta`)

En el esquema `eltransportador.collection/v1` (ya integrado en `apps/desktop/src/services/storage-sync.js`), cada colección, solicitud y flujo incorpora el bloque `syncMeta`:

```json
"syncMeta": {
  "policy": "local_only | remote_shared",
  "status": "local_only | pending_push | synced | conflict",
  "version": 3,
  "contentHash": "sha256:4a8b9012f...",
  "lastSyncedAt": "2026-10-14T20:10:00.000Z"
}
```

### Máquina de Estados de Sincronización y Etiquetas en Interfaz

| Política (`policy`) | Evento | Estado Resultante (`status`) | Etiqueta Visual en UI (ES / EN) |
| :--- | :--- | :--- | :--- |
| `local_only` | Creación o edición local | `local_only` | `🔒 Solo Local` / `🔒 Local Only` |
| `local_only` -> `remote_shared` | Usuario activa compartir en DynamoDB | `pending_push` | `⏳ Pendiente Sync` / `⏳ Pending Sync` |
| `remote_shared` | Usuario ejecuta **⬆ Enviar cambios a DynamoDB** (`PutItem` / `TransactWriteItems` exitoso) | `synced` | `☁ Sincronizado` / `☁ Synced` |
| `remote_shared` | Usuario edita URL, headers, body, nombre o carpeta de una entidad ya sincronizada | `pending_push` | `⏳ Pendiente Sync` / `⏳ Pending Sync` |
| `remote_shared` | Durante Push/Pull se detecta que `remote.version > local.version` con `contentHash` distinto | `conflict` | `⚠ Conflicto` / `⚠ Conflict` |

## 4. Flujo de Operaciones Local <-> DynamoDB

### 4.1 Envío Selectivo de Cambios Locales (`Push` hacia DynamoDB)
1. El motor filtra únicamente las entidades donde `syncMeta.policy === "remote_shared"` y `syncMeta.status === "pending_push"`. Las entidades marcadas como `local_only` son ignoradas por completo a nivel de red.
2. Antes de serializar el `payload`, pasa por `SecretRedactor` para garantizar que ningún valor de `SecretVault` viaje en texto plano.
3. Ejecuta un `PutItem` condicional con **Bloqueo Optimista (Optimistic Concurrency Control)**:
   ```text
   ConditionExpression: attribute_not_exists(PK) OR version = :expectedPrevVersion
   ```
4. Si DynamoDB responde `200 OK`, la entidad local actualiza `syncMeta.status = "synced"` y `syncMeta.lastSyncedAt = now()`. Si devuelve `ConditionalCheckFailedException`, el estado pasa a `conflict` para que el usuario elija conservar su versión local o aceptar la remota.

### 4.2 Descarga Incremental de Cambios (`Delta Pull` desde DynamoDB)
1. Al abrir el proyecto o pulsar **⬇ Obtener cambios remotos**, la aplicación consulta el índice `GSI1_DeltaSync` con:
   ```text
   KeyConditionExpression: GSI1PK = :ws AND GSI1SK > :lastWorkspaceSyncTimestamp
   ```
2. Solo se descargan los elementos modificados desde la última sincronización, minimizando el consumo de unidades de lectura (`RCU`) y manteniendo latencias inferiores a `50 ms`.

## 5. Plan de Implementación por Fases

1. **Fase 1 (Completada en `v1.0.0`):**
   - Estructura `syncMeta` integrada en colecciones, solicitudes y flujos en `apps/desktop/src/services/storage-sync.js`.
   - Etiquetas interactivas en tiempo real (`🔒 Solo Local`, `⏳ Pendiente Sync`, `☁ Sincronizado`) visibles en el árbol lateral de colecciones, en el editor central de solicitudes y en el Estudio de Flujos.
   - Modal dedicado **☁ Sincronización Híbrida Local-First y Amazon DynamoDB** (`#modal-sync-dynamodb`) para configurar `Endpoint`, `Tabla DynamoDB` y `Workspace ID`, cambiar el destino (`Local` vs `DynamoDB`) por elemento y enviar cambios pendientes.
2. **Fase 2 (Conector Nativo Rust AWS SDK / SigV4):**
   - Incorporar firma criptográfica **AWS Signature Version 4 (SigV4)** en el backend Rust (`apps/desktop/src-tauri/src/infrastructure/dynamodb_sync.rs`) leyendo credenciales desde el llavero seguro del sistema operativo (`ELTRANSPORTADOR_AWS_ACCESS_KEY_ID` / `AWS_PROFILE`) sin exponerlas al proceso de renderizado web.
3. **Fase 3 (Resolución Visual de Conflictos Diff 3-Way):**
   - Incorporar visor comparativo lado a lado cuando dos desarrolladores modifiquen la misma solicitud simultáneamente (`ConditionalCheckFailedException`), permitiendo fusionar cabeceras o cuerpos JSON antes de confirmar la versión final.
