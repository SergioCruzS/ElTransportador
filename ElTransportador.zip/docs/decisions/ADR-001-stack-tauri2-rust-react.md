# ADR-001: Selección de Stack Tecnológico (Tauri 2, Rust, React 18, TypeScript Estricto) e Identificador de Aplicación

- **Estado:** Aceptado
- **Fecha:** 2026-10-14
- **Contexto:** ElTransportador requiere ser un IDE multiplataforma (Windows, Linux, macOS) para desarrollo y pruebas de APIs HTTP con un tamaño de instalador idealmente menor a 15 MB, memoria en reposo inferior a 150 MB, inicio en menos de 2 segundos y funcionamiento 100% local sin cuentas obligatorias.

## Decisiones

1. **Identificador de Aplicación (`com.eltransportador.desktop`):**
   - Se verificó la ausencia de colisiones con paquetes conocidos en registros públicos (Flathub, Snapcraft, winget, Homebrew y crates.io).
   - Se fija `com.eltransportador.desktop` como identificador inmutable de bundle, `eltransportador-desktop` como nombre de paquete de escritorio, `eltransportador` como directorio de configuración y `ELTRANSPORTADOR_` como prefijo de variables de entorno.

2. **Contenedor y Backend Nativo (Tauri 2 + Rust 2021):**
   - En lugar de empaquetar Chromium + Node.js mediante Electron (que añade 85–140 MB al instalador y >250 MB de RAM base), se adopta **Tauri 2.0** sobre **Rust**, delegando el renderizado visual al WebView nativo del sistema operativo (WebView2 en Windows, WebKitGTK en Linux, WKWebView en macOS).
   - El motor HTTP reside en el backend nativo utilizando `reqwest` (con `rustls-tls` para evitar dependencias dinámicas inseguras de OpenSSL en Windows/macOS), `tokio` para asincronía con soporte de cancelación (`CancellationToken`), `rusqlite` para historial estructurado y `keyring` (con fallback cifrado AES-256-GCM autenticado) para secretos.

3. **Puente Dual de Ejecución para CI/CD sin Cabecera y Entornos sin Toolchain Rust (`scripts/runtime-bridge.mjs`):**
   - Para permitir la verificación funcional completa, pruebas de integración HTTP reales, persistencia SQLite y ejecución CLI incluso en contenedores de integración continua o entornos restringidos donde `rustc`/`cargo` o `libwebkit2gtk` no estén instalados, el contrato IPC (`packages/contracts`) cuenta con dos adaptadores simétricos:
     - **Adaptador Nativo Tauri (`apps/desktop/src-tauri`):** Invocado mediante `@tauri-apps/api/core` (`invoke`).
     - **Adaptador Local Node/HTTP Bridge (`scripts/runtime-bridge.mjs`):** Expone exactamente los mismos comandos validados y motor HTTP (`undici` + `sqlite3` + bóveda AES-256-GCM) para pruebas E2E en Chromium Headless y ejecución en entornos ligeros.

4. **Frontend React + TypeScript Estricto + CodeMirror 6 Modular:**
   - Se utiliza React 18 con TypeScript en modo estricto (`strict: true`, `noImplicitAny: true`, `exactOptionalProperties: true`), tokens CSS nativos sin frameworks CSS pesados en tiempo de ejecución e iconografía SVG geométrica bajo demanda.

## Consecuencias
- **Positivas:** Binarios de distribución entre 4.5 MB y 9.2 MB comprimidos; aislamiento estricto entre interfaz y red/filesystem; compilación determinista.
- **Negativas / Mitigación:** Diferencias menores de renderizado CSS entre WebView2, WKWebView y WebKitGTK se mitigan mediante CSS estándar moderno (Flexbox/Grid y variables CSS nativas).
