# ADR-002: Formato de Almacenamiento Propio Versionado (`eltransportador.collection/v1`) y Persistencia Híbrida

- **Estado:** Aceptado
- **Fecha:** 2026-10-14
- **Contexto:** Las colecciones de API deben poder versionarse limpiamente en Git, revisarse mediante `git diff`, respaldarse sin servicios en la nube y separarse estrictamente del historial de ejecuciones y de los secretos sensibles.

## Decisiones

1. **Esquema Propio `eltransportador.collection/v1` (`.etp.json`):**
   - Se define un esquema JSON determinista, ordenado por claves y con sangría de 2 espacios para maximizar la legibilidad en Git.
   - Campos raíz obligatorios:
     - `$schema`: `"https://eltransportador.dev/schemas/collection-v1.json"`
     - `schemaVersion`: `1`
     - `kind`: `"eltransportador.collection"`
     - `metadata`: `{ id, name, description, createdAt, updatedAt, appVersion }`
     - `defaults`: `{ timeoutMs, followRedirects, maxRedirects, verifyTls, headers }`
     - `variables`: Lista de variables públicas de colección (las variables secretas solo guardan `{ key, secretRef, isSecret: true }` sin valor en texto plano).
     - `folders`: Árbol jerárquico con identificadores estables (`fld_<uuid>`).
     - `requests`: Lista ordenada de solicitudes (`req_<uuid>`) con método, URL, parámetros, headers, autenticación, cuerpo, configuración de ejecución y aserciones declarativas (`assertions`).

2. **Escritura Atómica y Recuperación ante Fallos:**
   - Toda modificación de colección se escribe primero en un archivo temporal (`<nombre>.etp.json.tmp.<pid>`), se sincroniza en disco (`fsync`) y se renombra atómicamente sobre el archivo destino, conservando una copia de respaldo (`.etp.json.bak`) ante corrupciones o cierres inesperados.

3. **SQLite Exclusivamente para Historial e Índices Locales:**
   - El historial de ejecuciones se almacena en `~/.config/eltransportador/history.sqlite3` con política de retención configurable (por defecto 500 registros o 30 días) y redacción automática de cabeceras `Authorization`, `Cookie`, `X-API-Key`, tokens Bearer y variables secretas antes de escribir en disco.
