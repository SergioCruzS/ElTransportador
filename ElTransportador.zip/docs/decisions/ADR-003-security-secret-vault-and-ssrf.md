# ADR-003: Modelo de Seguridad, Protección de Secretos y Control de Redirecciones

- **Estado:** Aceptado
- **Fecha:** 2026-10-14
- **Contexto:** Un cliente de API maneja credenciales críticas (tokens OAuth/Bearer, API Keys, contraseñas Basic Auth, certificados) y se conecta tanto a servidores en producción como a servicios locales o de terceros potencialmente maliciosos.

## Decisiones

1. **Separación Estricta de Secretos y Redacción Universal:**
   - Ningún secreto se almacena por defecto en texto plano dentro de las colecciones ni en el historial SQLite.
   - Los secretos se almacenan en el llavero del sistema operativo (`keyring`: Secret Service en Linux, Keychain en macOS, Credential Manager en Windows) o en una bóveda local cifrada con **AES-256-GCM** y clave derivada por entorno cuando el llavero gráfico no está disponible.
   - El motor de redacción (`SecretRedactor`) inspecciona URLs, headers, cuerpos, logs y errores antes de persistir en el historial o exportar diagnósticos, reemplazando cualquier coincidencia de valores secretos o patrones de credenciales por `[REDACTED:ELTRANSPORTADOR_SECRET]`.

2. **Sintaxis de Interpolación Determinista y Sin Ambigüedad:**
   - Variables estándar: `${ nombre_variable }` con precedencia explícita: `Flujo/Runtime > Entorno Activo > Colección > Global (ELTRANSPORTADOR_*)`.
   - Secretos: `${secret:nombre_secreto}`, resueltos únicamente en memoria en el instante de construir el socket HTTP y nunca volcados de vuelta al estado serializado de la colección.

3. **Política de Red y Redirecciones Seguras:**
   - Solo se permiten esquemas `http://` y `https://`. Se bloquean estrictamente `file://`, `javascript:`, `data:`, `ftp://`, `gopher://` y `ws://` en el motor HTTP.
   - En cada salto de redirección (`301`, `302`, `303`, `307`, `308`):
     - Se revalida el esquema y el host de destino.
     - Si cambia el origen (`scheme + host + port`), se **eliminan automáticamente** las cabeceras `Authorization`, `Cookie`, `Proxy-Authorization` y cualquier cabecera que contenga un secreto interpolado (prevención de fuga de tokens por redirección abierta).
     - Si una solicitud hacia un host público intenta redirigir hacia una dirección IP privada/loopback (`127.0.0.0/8`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `169.254.169.254`, `::1`), la redirección es bloqueada por la política anti-SSRF cross-zone a menos que el usuario lo autorice explícitamente.
