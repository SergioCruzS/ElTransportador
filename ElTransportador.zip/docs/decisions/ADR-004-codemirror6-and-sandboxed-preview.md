# ADR-004: Arquitectura del Editor de Código y Vista Previa HTML Aislada

- **Estado:** Aceptado
- **Fecha:** 2026-10-14
- **Contexto:** El usuario necesita editar cargas JSON/texto con validación sintáctica, formateo, numeración de líneas, plegado y búsqueda, además de inspeccionar respuestas HTML sin riesgo de Cross-Site Scripting (XSS) ni acceso al contexto privilegiado de Tauri.

## Decisiones

1. **Editor de Código Ligero y Modular:**
   - Se implementa una capa de edición compatible con la arquitectura de extensiones de CodeMirror 6 con soporte nativo para resaltado JSON, validación en tiempo real con indicador de línea/columna del error, formateo (`Prettify` / `Minify`), plegado de bloques JSON (`{...}`, `[...]`), numeración de líneas y búsqueda integrada (`Ctrl+F`), cargando las utilidades de formato bajo demanda.

2. **Vista Previa HTML con Aislamiento Total (`sandbox=""`):**
   - La pestaña `Preview` del visor de respuestas renderiza documentos HTML exclusivamente dentro de un `<iframe sandbox="" referrerpolicy="no-referrer">` con una política CSP `default-src 'none'; style-src 'unsafe-inline'; img-src data:;` inyectada en el documento previsualizado.
   - Se prohíbe `allow-scripts`, `allow-same-origin`, `allow-forms` y `allow-popups`, garantizando que ningún payload XSS devuelto por un servidor externo pueda ejecutar JavaScript ni invocar `window.__TAURI_INTERNALS__`.
